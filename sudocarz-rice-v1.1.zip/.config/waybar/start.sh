#!/bin/sh
PIDFILE=/tmp/waybar-loop.pid
[ -f "$PIDFILE" ] && kill "$(cat "$PIDFILE")" 2>/dev/null
echo $$ > "$PIDFILE"
pkill -x waybar
sleep 1
while true; do
  waybar >> /tmp/waybar.log 2>&1
  sleep 1
done
